# Escola da Casa — Delícias da Vovó

Protótipo estático de uma plataforma interna de treinamentos para a equipe.

## Versão inicial
- Tipografia **Newsreader** em títulos e **DM Sans** no corpo do texto.
- 10 módulos de treinamento com aulas de demonstração.
- Busca, filtros por categoria e ordenação.
- Conclusão de aulas salva **somente no navegador** (localStorage).
- Interface adaptada a celular e computador.

## Como visualizar
Abra `index.html` no navegador. Nenhuma instalação é necessária. É preciso acesso à internet para carregar as fontes do Google Fonts.

## Como publicar no GitHub Pages (somente se o conteúdo puder ser público)
1. Crie um repositório no GitHub, por exemplo `escola-da-casa`.
2. Envie `index.html` e este README para a raiz do repositório.
3. Em **Settings → Pages**, selecione **Deploy from a branch → main → /(root)**.
4. A página gerada pelo GitHub Pages costuma ser **publicamente acessível**. Não publique dados pessoais, credenciais nem manuais internos sensíveis sem controlar o acesso.

## Próximos passos
Para uso real com funcionários: autenticação individual, controle de permissões, banco de dados, validação dos POPs, anexos, vídeos, trilhas por função e relatórios de conclusão. **O arquivo atual é apenas uma demonstração e não oferece controle de acesso ou rastreamento individual.**

Os textos de treinamento deste protótipo são propostas de roteiro; valide-os com responsáveis de cada setor antes de adotá-los como instrução oficial.
